# Nick Gist, TwiceBetter
# gist.tb A gmail com
#
# Driven Keys Importer to MotionBuilder

from pyfbsdk import FBLayout, ShowTool, SetToolSize, FBAddRegionParam, FBAttachType, FBButton, FBTextJustify, FBSystem, FBConstraintRelation, FBPropertyListConstraint, FBModelMarker, FBDisconnect, FBConnect, FBTime, FBModelPlaceHolder, FBInterpolation, FBTangentMode, FBTangentClampMode, FBTangentConstantMode, FBExtrapolationMode, FBView
from pyfbsdk_additions import FBCreateUniqueTool, FBHBoxLayout, FBVBoxLayout
import time
import threading

def TBSDKdataObject(objectNum):
    sceneRootChildren = FBSystem().Scene.RootModel.Children
    for rootChild in sceneRootChildren:
        if rootChild.Name == "TBSDKexportData_"+str(objectNum):
            return rootChild
def TBSDKpopProperty(name,propertyList):
    propCount = len(propertyList)
    for i in range(0,propCount):
        prop = propertyList[i]
        if prop.Name == name:
            del(propertyList[i])
            return prop
    return None
def TBSDKfindAnimationNode(parent,name):
    result = None
    for node in parent.Nodes:
        if node.Name == name:
            result = node
            break
    return result
def TBSDKconstructCurve(curve, propertyNodeI, extraAttributes):
    propertySign = "_" + str(propertyNodeI) + "k"
    keysNum = TBSDKpopProperty(propertySign + "n", extraAttributes).Data
    curve.EditClear()
    curve.EditBegin()
    for i in range(1,keysNum+1):
        sign = propertySign + str(i)
        dV = TBSDKpopProperty(sign + "d", extraAttributes)
        vV = TBSDKpopProperty(sign + "v", extraAttributes)
        lT = TBSDKpopProperty(sign + "l", extraAttributes).Data
        rT = TBSDKpopProperty(sign + "r", extraAttributes).Data
        keyTime = FBTime()
        keyTime.SetSecondDouble(dV)
        keyI = curve.KeyAdd(keyTime, vV)
        key = curve.Keys[keyI]
        if rT == 1:
            #spline
            key.Interpolation = FBInterpolation.kFBInterpolationCubic
            key.TangentMode = FBTangentMode.kFBTangentModeTimeIndependent
        elif rT == 2:
            #linear
            key.Interpolation = FBInterpolation.kFBInterpolationLinear
        elif rT == 7:
            #step
            key.Interpolation = FBInterpolation.kFBInterpolationConstant
            key.TangentConstantMode = FBTangentConstantMode.kFBTangentConstantModeNormal
        elif rT == 8:
            #stepnext
            key.Interpolation = FBInterpolation.kFBInterpolationConstant
            key.TangentConstantMode = FBTangentConstantMode.kFBTangentConstantModeNext
        else:
            #default is auto
            key.Interpolation = FBInterpolation.kFBInterpolationCubic
            key.TangentMode = FBTangentMode.kFBTangentModeClampProgressive
            key.TangentClampMode = FBTangentClampMode.kFBTangentClampModeNone
    curve.EditEnd()
    preInfinity = TBSDKpopProperty("_" + str(propertyNodeI) + "pr", extraAttributes).Data
    postInfinity = TBSDKpopProperty("_" + str(propertyNodeI) + "po", extraAttributes).Data
    if preInfinity == 0: curve.SetPreExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationConst)
    if postInfinity == 0: curve.SetPostExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationConst)
    if preInfinity == 1: curve.SetPreExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationKeepSlope)
    if postInfinity == 1: curve.SetPostExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationKeepSlope)
    if preInfinity == 3: curve.SetPreExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationRepetition)
    if postInfinity == 3: curve.SetPostExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationRepetition)
    if preInfinity == 4: curve.SetPreExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationRelativeRepetition)
    if postInfinity == 4: curve.SetPostExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationRelativeRepetition)
    if preInfinity == 5: curve.SetPreExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationMirrorRepetition)
    if postInfinity == 5: curve.SetPostExtrapolationMode(FBExtrapolationMode.kFCurveExtrapolationMirrorRepetition)
    curve.SetPreExtrapolationCount(-1)
    curve.SetPostExtrapolationCount(-1)
def TBSDKdetermineDriverBox(constraint, driverObject):
    for box in constraint.Boxes:
        if type(box) == FBModelPlaceHolder and box.Model == driverObject:
            tempR, x, y = constraint.GetBoxPosition(box)
            if tempR and x == 40:
                return box
    sendersCount = 0
    for box in constraint.Boxes:
        if type(box) == FBModelPlaceHolder:
            sendersCount += 1
    driverBox = constraint.SetAsSource(driverObject)
    driverBox.UseGlobalTransforms = False
    constraint.SetBoxPosition(driverBox, 40, 40 + (sendersCount - 1) * 480)
    return driverBox
def TBSDKdetermineDriverChannelOutNode(constraint, driverBox, driverPropertyType, driverPropertyAxis):
    tempR, driverBoxX, driverBoxY = constraint.GetBoxPosition(driverBox)
    driverChannelOutName = None
    vecToNumShift = None
    if driverPropertyType == "T":
        driverChannelOutName = "Lcl Translation"
        vecToNumShift = 2
    elif driverPropertyType == "R":
        driverChannelOutName = "Lcl Rotation"
        vecToNumShift = 0
    elif driverPropertyType == "S":
        driverChannelOutName = "Lcl Scaling"
        vecToNumShift = 1
    driverOutNode = TBSDKfindAnimationNode(driverBox.AnimationNodeOutGet(), driverChannelOutName)
    vecToNumBoxX = 40
    vecToNumBoxY = driverBoxY + 100 + vecToNumShift * 120
    vecToNumBox = None
    for box in constraint.Boxes:
        tempR, x, y = constraint.GetBoxPosition(box)
        if tempR and x == vecToNumBoxX and y == vecToNumBoxY:
            vecToNumBox = box
            break
    if not vecToNumBox:
        vecToNumBox = constraint.CreateFunctionBox("Converters", "Vector To Number")
        constraint.SetBoxPosition(vecToNumBox, vecToNumBoxX, vecToNumBoxY)
        vecToNumBox.Name = "|" + driverBox.Model.Name + "_" + driverPropertyType + "|"
        FBConnect(driverOutNode, TBSDKfindAnimationNode(vecToNumBox.AnimationNodeInGet(), "V"))
    vecToNumBoxOut = TBSDKfindAnimationNode(vecToNumBox.AnimationNodeOutGet(), driverPropertyAxis)
    secToTimeShift = None
    if driverPropertyAxis == "X": secToTimeShift = 0
    elif driverPropertyAxis == "Y": secToTimeShift = 1
    elif driverPropertyAxis == "Z": secToTimeShift = 2
    secToTimeBoxX = 60
    secToTimeBoxY = vecToNumBoxY + 20 + secToTimeShift * 20
    secToTimeBox = None
    for box in constraint.Boxes:
        tempR, x, y = constraint.GetBoxPosition(box)
        if tempR and x == secToTimeBoxX and y == secToTimeBoxY:
            secToTimeBox = box
            break
    if not secToTimeBox:
        secToTimeBox = constraint.CreateFunctionBox("Converters", "Seconds to Time")
        constraint.SetBoxPosition(secToTimeBox, secToTimeBoxX, secToTimeBoxY)
        secToTimeBox.Name = "|" + driverPropertyType + "_" + driverPropertyAxis + "|"
        FBConnect(vecToNumBoxOut, TBSDKfindAnimationNode(secToTimeBox.AnimationNodeInGet(), "Seconds"))
    secToTimeBoxOut = TBSDKfindAnimationNode(secToTimeBox.AnimationNodeOutGet(), "Result")
    return secToTimeBoxOut
def TBSDKconstructConstraintChain(constraint, lastInNode, propertyNodeI, extraAttributes, constrainProperty):
    nodeType = TBSDKpopProperty("_"+str(propertyNodeI)+"t", extraAttributes).Data
    if nodeType == 1:
        curvesNum = 0
        for box in constraint.Boxes:
            if box.Name[:8] == "|FCurve_":
                curvesNum += 1
        curveBox = constraint.CreateFunctionBox("Other", "FCurve Number (Time)")
        constraint.SetBoxPosition(curveBox, 400, 40 + curvesNum * 80)
        curveBox.Name = "|FCurve_" + str(propertyNodeI) + "|"
        curveBoxInNode = TBSDKfindAnimationNode(curveBox.AnimationNodeInGet(), "Position")
        curveBoxOutNode = TBSDKfindAnimationNode(curveBox.AnimationNodeOutGet(), "Value")
        TBSDKconstructCurve(curveBoxOutNode.FCurve, propertyNodeI, extraAttributes)
        FBConnect(curveBoxOutNode, lastInNode)
        
        driverObjectPath, driverObjectProperty = TBSDKsplitObjectPathAndProperty(TBSDKpopProperty("_" + str(propertyNodeI) + "c", extraAttributes))
        driverObject = TBSDKobjectByFullPath(driverObjectPath)
        if driverObject == None:
            return False
        driverPropertyType = TBSDKdeterminePropertyType(driverObjectProperty)
        driverPropertyAxis = driverObjectProperty[-1:]
        
        driverBox = TBSDKdetermineDriverBox(constraint, driverObject)
        driverChannelOutNode = TBSDKdetermineDriverChannelOutNode(constraint, driverBox, driverPropertyType, driverPropertyAxis)
        
        FBConnect(driverChannelOutNode, curveBoxInNode)
    elif nodeType == 2:
        blendsNum = 0
        for box in constraint.Boxes:
            if box.Name[:7] == "|Blend ":
                blendsNum += 1
        blendedNum = TBSDKpopProperty("_"+str(propertyNodeI)+"bn", extraAttributes).Data
        sum10numbersBox = constraint.CreateFunctionBox("Number", "Sum 10 numbers")
        constraint.SetBoxPosition(sum10numbersBox, 720, 40 + blendsNum * 280)
        sum10numbersBox.Name = "|Blend " + constrainProperty + "|"
        sum10numbersBoxOut = TBSDKfindAnimationNode(sum10numbersBox.AnimationNodeOutGet(), "Result")
        
        FBConnect(sum10numbersBoxOut, lastInNode)
        currentSumBoxNumber = 1
        for i in range(0,blendedNum):
            sumBoxNumber = 1 + (i // 9)
            if sumBoxNumber != currentSumBoxNumber:
                prevBoxLastIn = sum10numbersBox.AnimationNodeInGet().Nodes[9]
                NSB = constraint.CreateFunctionBox("Number", "Sum 10 numbers")
                blendsNum += 1
                constraint.SetBoxPosition(NSB, 720, 40 + blendsNum * 280)
                NSB.Name = "|Blend " + constrainProperty + "|"
                NSBout = TBSDKfindAnimationNode(NSB.AnimationNodeOutGet(), "Result")
                FBConnect(NSBout, prevBoxLastIn)
                sum10numbersBox = NSB
                currentSumBoxNumber = sumBoxNumber
            blendedNodeI = propertyNodeI + 1 + i
            sumNodeIn = sum10numbersBox.AnimationNodeInGet().Nodes[i % 9]
            
            TBSDKconstructConstraintChain(constraint, sumNodeIn, blendedNodeI, extraAttributes, constrainProperty)
    else:
        print "TBSDK Error: unknown node type " + str(nodeType)
        return False
    return True
def TBSDKconstructConstraintPropertyChannel(constraint, extraAttributes, propertyChannelI, propertyAxis, constrainProperty):
    propertyChannelNodeI = TBSDKpopProperty("dcn_"+str(propertyChannelI), extraAttributes).Data
    lastConverterBox = None
    for box in constraint.Boxes:
        if box.Name[:16] == "|Last Converter|":
            lastConverterBox = box
    if not lastConverterBox: return False
    lastConverterInNode = TBSDKfindAnimationNode(lastConverterBox.AnimationNodeInGet(), propertyAxis)
    result = TBSDKconstructConstraintChain(constraint, lastConverterInNode, propertyChannelNodeI, extraAttributes, constrainProperty)
    return result
def TBSDKgetExtraAttributes(attributesObject):
    attributes = []
    propCount = len(attributesObject.PropertyList)
    for i in range(0,propCount):
        prop = attributesObject.PropertyList[i]
        if prop.IsUserProperty():
            attributes.append(prop)
    return attributes
def TBSDKgetDrivenChannelsNum(extraAttributes):
    num = 0
    for prop in extraAttributes:
        if prop.Name[:3] == "dc_":
            num += 1
    return num
def TBSDKgetDrivenObjectPathAndProperty(extraAttributes, attributeI):
    return TBSDKsplitObjectPathAndProperty(TBSDKpopProperty("dc_"+str(attributeI), extraAttributes))
def TBSDKsplitObjectPathAndProperty(splitInput):
    lastDotI = splitInput.Data.rfind(".")
    if lastDotI < 0: return None, None
    else: return splitInput.Data[:lastDotI], splitInput.Data[lastDotI+1:]
def TBSDKobjectByFullPath(objectPath):
    parent = FBSystem().Scene.RootModel
    pathArray = objectPath[1:].split("|")
    for name in pathArray:
        found = False
        for child in parent.Children:
            if child.Name == name:
                parent = child
                found = True
                break
        if not found:
            return None
    return parent
def TBSDKdeterminePropertyType(objectProperty):
    propertyType = None
    if objectProperty[:1] == "t": propertyType = "T"
    elif objectProperty[:1] == "r": propertyType = "R"
    elif objectProperty[:1] == "s": propertyType = "S"
    return propertyType
def TBSDKdetermineConstraint(objectPath, propertyType, createdConstraints):
    constraintName = "TBSDK_" + objectPath + "_" + propertyType
    determinedConstraint = None
    for constraint in createdConstraints:
        if constraint.Name == constraintName:
            return constraint
    for constraint in FBSystem().Scene.Constraints:
        if constraint.Name == constraintName:
            while len(constraint.Boxes) > 0: del(constraint.Boxes[0])
            determinedConstraint = constraint
            break
    if not determinedConstraint: determinedConstraint = FBConstraintRelation(constraintName)
    drivenChannelObject = TBSDKobjectByFullPath(objectPath)
    drivenChannelObjectBox = determinedConstraint.ConstrainObject(drivenChannelObject)
    drivenChannelObjectBox.UseGlobalTransforms = False
    determinedConstraint.SetBoxPosition(drivenChannelObjectBox, 1040, 40)
    drivenChannelInName = ""
    if propertyType == "T": drivenChannelInName = "Lcl Translation"
    elif propertyType == "R": drivenChannelInName = "Lcl Rotation"
    elif propertyType == "S": drivenChannelInName = "Lcl Scaling"
    drivenChannelObjectIn = TBSDKfindAnimationNode(drivenChannelObjectBox.AnimationNodeInGet(), drivenChannelInName)
    lastConverterBox = determinedConstraint.CreateFunctionBox("Converters", "Number to Vector")
    lastConverterBox.Name = "|Last Converter|"
    determinedConstraint.SetBoxPosition(lastConverterBox, 1040, 160)
    lastConverterOut = TBSDKfindAnimationNode(lastConverterBox.AnimationNodeOutGet(), "Result")
    dcoD = None
    if propertyType == "T": dcoD = drivenChannelObject.Translation
    elif propertyType == "R": dcoD = drivenChannelObject.Rotation
    elif propertyType == "S": dcoD = drivenChannelObject.Scaling
    lcbanin = lastConverterBox.AnimationNodeInGet()
    for a in lcbanin.Nodes:
        if a.Name == "X": a.WriteData([dcoD[0]])
        elif a.Name == "Y": a.WriteData([dcoD[1]])
        elif a.Name == "Z": a.WriteData([dcoD[2]])
    FBConnect(lastConverterOut, drivenChannelObjectIn)
    createdConstraints.append(determinedConstraint)
    return determinedConstraint
def TBSDKupdateClick(control, event):
    updateThread = threading.Thread(None, target = TBSDKupdateThread, args = ())
    updateThread.start()
def TBSDKactivateClick(control, event):
    TBSDKsetAllActive(True)
def TBSDKdeactivateClick(control, event):
    TBSDKsetAllActive(False)
def TBSDKsetAllActive(active):
    sceneConstraints = FBSystem().Scene.Constraints
    changedConstraintsNum = 0
    constraintsNum = len(sceneConstraints)
    for i in range(0,constraintsNum):
        if sceneConstraints[i].Name[:6] == "TBSDK_":
            if (sceneConstraints[i].Active != active):
                sceneConstraints[i].Active = active
                changedConstraintsNum += 1
    global TBSDKIMPstatusLabel
    if changedConstraintsNum == 0:
        if active:
            TBSDKIMPstatusLabel.Caption = "nothing to activate"
        else:
            TBSDKIMPstatusLabel.Caption = "nothing to deactivate"
    else:
        if active:
            TBSDKIMPstatusLabel.Caption = "activated " + str(changedConstraintsNum) + " constraints"
        else:
            TBSDKIMPstatusLabel.Caption = "deactivated " + str(changedConstraintsNum) + " constraints"
    del(sceneConstraints)
    FBSystem().Scene.Evaluate()
def TBSDKremoveClick(control, event):
    sceneConstraints = FBSystem().Scene.Constraints
    allChecked = False
    removedConstraintsNum = 0
    while not allChecked:
        allChecked = True
        constraintsNum = len(sceneConstraints)
        for i in range(0,constraintsNum):
            if sceneConstraints[i].Name[:6] == "TBSDK_":
                allChecked = False
                sceneConstraints[i].Active = False
                del(sceneConstraints[i])
                removedConstraintsNum += 1
                break
    global TBSDKIMPstatusLabel
    if removedConstraintsNum == 0:
        TBSDKIMPstatusLabel.Caption = "nothing to remove"
    else:
        TBSDKIMPstatusLabel.Caption = "removed " + str(removedConstraintsNum) + " constraints"
    del(sceneConstraints)
def TBSDKdeleteDataClick(control, event):
    done = False
    dataObjectNum = 0
    deletedNum = 0;
    while not done:
        dataObjectNum += 1
        dataObject = TBSDKdataObject(dataObjectNum)
        if dataObject:
            dataObject.FBDelete()
            deletedNum += 1
        else:
            done = True
    global TBSDKIMPstatusLabel
    if deletedNum == 0:
        TBSDKIMPstatusLabel.Caption = "nothing to delete"
    else:
        TBSDKIMPstatusLabel.Caption = "deleted " + str(deletedNum) + " data objects"
def TBSDKupdateThread():
    global TBSDKIMPstatusLabel
    TBSDKIMPstatusLabel.Caption = ""
    dataObjectNum = 0
    done = False
    dataObjectFirstChannelI = 1
    createdConstraints = []
    updatedChannelsNum = 0
    while not done:
        dataObjectNum += 1
        dataObject = TBSDKdataObject(dataObjectNum)
        if dataObject:
            extraAttributes = TBSDKgetExtraAttributes(dataObject)
            drivenChannelsNum = TBSDKgetDrivenChannelsNum(extraAttributes)
            for i in range(dataObjectFirstChannelI, dataObjectFirstChannelI + drivenChannelsNum):
                objectPath, objectProperty = TBSDKgetDrivenObjectPathAndProperty(extraAttributes, i)
                if not objectProperty: continue
                drivenObject = TBSDKobjectByFullPath(objectPath)
                if not drivenObject: continue
                propertyType = TBSDKdeterminePropertyType(objectProperty)
                if not propertyType: continue
                constraint = TBSDKdetermineConstraint(objectPath, propertyType, createdConstraints)
                wasActive = constraint.Active
                if wasActive:
                    constraint.Active = False
                    FBSystem().Scene.Evaluate()
                result = TBSDKconstructConstraintPropertyChannel(constraint, extraAttributes, i, objectProperty[-1:], objectProperty)
                if result:
                    constraint.Active = True
                    FBSystem().Scene.Evaluate()
                    updatedChannelsNum += 1
                TBSDKIMPstatusLabel.Caption = str(updatedChannelsNum) + " channels updated"
                FBSystem().Scene.Evaluate()
                time.sleep(0.000001)
            dataObjectFirstChannelI += drivenChannelsNum
            del(extraAttributes)
        else:
            done = True
    TBSDKIMPstatusLabel.Caption = "Done. " + str(updatedChannelsNum) + " channels updated"
def TBSDKconstructWindow(mainLayout):
    mainLayout.StartSizeX = 190
    mainLayout.StartSizeY = 176
    mainLayout.MinSizeX = 190
    mainLayout.MinSizeY = 176
    x = FBAddRegionParam(1, FBAttachType.kFBAttachLeft, "")
    y = FBAddRegionParam(0, FBAttachType.kFBAttachTop, "")
    w = FBAddRegionParam(-5, FBAttachType.kFBAttachRight, "")
    h = FBAddRegionParam(0, FBAttachType.kFBAttachBottom, "")
    main = FBVBoxLayout()
    mainLayout.AddRegion("main","main",x,y,w,h)
    mainLayout.SetControl("main",main)
    hstripes = FBVBoxLayout()
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    updateButton = FBButton()
    updateButton.Caption = "Update"
    updateButton.OnClick.Add(TBSDKupdateClick)
    box.AddRelative(updateButton,1.0)
    hstripes.Add(box,26)
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    activateButton = FBButton()
    activateButton.Caption = "Activate"
    activateButton.OnClick.Add(TBSDKactivateClick)
    box.AddRelative(activateButton,1.0)
    hstripes.Add(box,26)
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    deactivateButton = FBButton()
    deactivateButton.Caption = "Deactivate"
    deactivateButton.OnClick.Add(TBSDKdeactivateClick)
    box.AddRelative(deactivateButton,1.0)
    hstripes.Add(box,26)
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    removeButton = FBButton()
    removeButton.Caption = "Remove"
    removeButton.OnClick.Add(TBSDKremoveClick)
    box.AddRelative(removeButton,1.0)
    hstripes.Add(box,26)
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    deleteDataButton = FBButton()
    deleteDataButton.Caption = "Delete data objects"
    deleteDataButton.OnClick.Add(TBSDKdeleteDataClick)
    box.AddRelative(deleteDataButton,1.0)
    hstripes.Add(box,26)
    box = FBHBoxLayout(FBAttachType.kFBAttachLeft)
    global TBSDKIMPstatusLabel
    TBSDKIMPstatusLabel = FBLabel()
    TBSDKIMPstatusLabel.Justify = FBTextJustify.kFBTextJustifyRight;
    TBSDKIMPstatusLabel.Caption = ""
    box.AddRelative(TBSDKIMPstatusLabel,1.0)
    hstripes.Add(box,12)
    main.Add(hstripes,176)

# Window
TBSDKimportTool = FBCreateUniqueTool("TB SDK Import")
TBSDKconstructWindow(TBSDKimportTool)
ShowTool(TBSDKimportTool)