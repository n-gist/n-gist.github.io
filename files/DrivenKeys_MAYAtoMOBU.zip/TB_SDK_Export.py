# Nick Gist, TwiceBetter
# gist.tb A gmail com
#
# Driven Keys Exporter from MAYA

import maya.cmds as mc
import maya.mel as mel

def TBSDKEXPsetResultText(resStr):
    mc.text(TBSDKEXPresultText, e=True, l=resStr)
def TBSDKEXPcurveInfinityString(infinityTypeID):
    if infinityTypeID == 0: return "constant"
    elif infinityTypeID == 1: return "linear"
    elif infinityTypeID == 3: return "cycle"
    elif infinityTypeID == 4: return "cycleoffset"
    elif infinityTypeID == 5: return "oscillate"
    else: return "constant"
def TBSDKEXPcurveTangentTypeString(tangentTypeID):
    if tangentTypeID == "auto": return 0
    elif tangentTypeID == "spline": return 1
    elif tangentTypeID == "linear": return 2
    elif tangentTypeID == "clamped": return 3
    elif tangentTypeID == "flat": return 4
    elif tangentTypeID == "fixed": return 5
    elif tangentTypeID == "plateau": return 6
    elif tangentTypeID == "step": return 7
    elif tangentTypeID == "stepnext": return 8
    else: return 0
def TBSDKEXPconstructConstrainDataDrivenChannel(channel, construct, sceneObject):
    if (not construct) and TBSDKEXPwl: print "      |\n      <<< CHANNEL " + channel
    drivenChannelLastNode = mc.listConnections(channel)[0]
    result = TBSDKEXPconstructConstrainDataNodeBackward(drivenChannelLastNode, construct, sceneObject, "")
    if result:
        if (not construct) and TBSDKEXPwl: print "      >>> CHANNEL OKAY " + channel
        return True
    else:
        if (not construct) and TBSDKEXPwl: print "      >>> CHANNEL BAD " + channel
        return False

def TBSDKEXPconstructConstrainDataNodeBackward(node, construct, parentNode, ds):
    global TBSDKEXPnI
    _nodeType = mc.objectType(node)
    _parentNodeType = mc.objectType(parentNode)
    if (not construct) and TBSDKEXPwl: print ds + "           - NODE " + node + " TYPE " + _nodeType + " -"
    if _nodeType in ("animCurveUL","animCurveUU","animCurveUA","animCurveUT",):
        if _parentNodeType in ("transform", "joint", "blendWeighted", "unitConversion"):
            if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE OKAY " + _parentNodeType
            curveKeysCount = int(mc.keyframe(node, q=True, kc=True))
            if curveKeysCount > 0:
                if (not construct) and TBSDKEXPwl: print ds + "             ! CURVE OKAY " + str(curveKeysCount) + " KEYS"
                curveData = mc.listConnections(node, s=True, d=False, scn=True, c=True)
                curveInputChannel = curveData[0]
                curveDriver = mc.ls(curveData[1], l=True)[0]
                curveDriverChannelData = mc.listConnections(curveInputChannel, s=True, d=False, scn=True, p=True)
                curveDriverChannel = mc.ls(curveDriverChannelData[0], l=True)[0]
                curveDriverType = mc.objectType(curveDriver)
                lastKeyIndex = int(curveKeysCount - 1)
                curveFrames = mc.keyframe(node, q=True, index=(0,lastKeyIndex), vc=True, fc=True)
                if (not construct) and TBSDKEXPwl: print ds + "               " + str(curveFrames)
                curveTangents = mc.keyTangent(node, q=True, index=(0,lastKeyIndex), itt=True, ott=True)
                if (not construct) and TBSDKEXPwl: print ds + "               " + str(curveTangents)
                curvePreInfinity = mc.getAttr(node + ".preInfinity")
                curvePostInfinity = mc.getAttr(node + ".postInfinity")
                if (not construct) and TBSDKEXPwl: print ds + "               pri = " + TBSDKEXPcurveInfinityString(curvePreInfinity)
                if (not construct) and TBSDKEXPwl: print ds + "               poi = " + TBSDKEXPcurveInfinityString(curvePostInfinity)
                if (not construct) and TBSDKEXPwl: print ds + "               - CURVE DRIVER " + curveDriverChannel + " - "
                if curveDriverType == "transform":
                    if (not construct) and TBSDKEXPwl: print ds + "                 ! CURVE DRIVER TYPE OKAY " + curveDriverType
                    if construct:
                        nodeSign = "_"+str(TBSDKEXPnI)
                        mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"t", nn=nodeSign+"t", at="long", dv=1)
                        mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"kn", nn=nodeSign+"kn", at="long", dv=curveKeysCount)
                        for k in range(0,curveKeysCount):
                            keySign = nodeSign+"k"+str(k+1)
                            mc.addAttr(TBSDKEXPexportDataObject, ln=keySign+"d", nn=keySign+"d", at="float", dv=curveFrames[k*2])
                            mc.addAttr(TBSDKEXPexportDataObject, ln=keySign+"v", nn=keySign+"v", at="float", dv=curveFrames[k*2+1])
                            mc.addAttr(TBSDKEXPexportDataObject, ln=keySign+"l", nn=keySign+"l", at="long", dv=TBSDKEXPcurveTangentTypeString(curveTangents[k*2]))
                            mc.addAttr(TBSDKEXPexportDataObject, ln=keySign+"r", nn=keySign+"r", at="long", dv=TBSDKEXPcurveTangentTypeString(curveTangents[k*2+1]))
                        mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"pr", nn=nodeSign+"pr", at="long", dv=curvePreInfinity)
                        mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"po", nn=nodeSign+"po", at="long", dv=curvePostInfinity)
                        mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"c", nn=nodeSign+"c", dt="string")
                        mc.setAttr(TBSDKEXPexportDataObject + "."+nodeSign+"c", curveDriverChannel, type="string")            
                        TBSDKEXPnI += 1
                    return True
                else:
                    if (not construct) and TBSDKEXPwl: print ds + "                 ! CURVE DRIVER TYPE BAD " + curveDriverType
                    return False
            else:
                if (not construct) and TBSDKEXPwl: print ds + "             ! CURVE BAD 0 KEYS"
                return False
        else:
            if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE BAD " + _parentNodeType
            return False
    elif _nodeType == "blendWeighted":
        if _parentNodeType in ("transform", "joint", "unitConversion"):
            if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE OKAY " + _parentNodeType
            weightedInputNodes = mc.listConnections(node, s=True, d=False)
            if construct:
                nodeSign = "_"+str(TBSDKEXPnI)
                mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"t", nn=nodeSign+"t", at="long", dv=2)
                mc.addAttr(TBSDKEXPexportDataObject, ln=nodeSign+"bn", nn=nodeSign+"bn", at="long", dv=len(weightedInputNodes))
                TBSDKEXPnI += 1
            allInputsOk = True
            for weightedInputNode in weightedInputNodes:
                result = TBSDKEXPconstructConstrainDataNodeBackward(weightedInputNode, construct, node, ds + "     ")
                if result == False:
                    allInputsOk = False
            if allInputsOk:
                if (not construct) and TBSDKEXPwl: print "             ! WEIGHTED INPUTS OKAY"
                return True
            else:
                if (not construct) and TBSDKEXPwl: print "             ! WEIGHTED INPUTS BAD"
                return False
        else:
            if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE BAD " + _parentNodeType
            return False
    elif _nodeType == "unitConversion":
    	if _parentNodeType in ("transform", "joint", "blendWeighted"):
    		if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE OKAY " + _parentNodeType
    		conversionInputNodes = mc.listConnections(node, s=True, d=False)
    		allInputsOk = True
    		if not conversionInputNodes:
    			allInputsOk = False
    		else:
    			if len(conversionInputNodes) == 1:
    				result = TBSDKEXPconstructConstrainDataNodeBackward(conversionInputNodes[0], construct, node, ds + "     ")
    				if result == False:
    					allInputsOk = False
    			else:
    				allInputsOk = False
    		if allInputsOk:
    			if (not construct) and TBSDKEXPwl: print "             ! CONVERSION INPUT OKAY"
    			return True
    		else:
    			if (not construct) and TBSDKEXPwl: print "             ! CONVERSION INPUT BAD"
    			return False
    	else:
    		if (not construct) and TBSDKEXPwl: print ds + "             ! PARENT NODE TYPE BAD --------------------!!!!!!!!!!!!!!!!!!------------------" + _parentNodeType
    		return False
    else:
        if (not construct) and TBSDKEXPwl: print ds + "             ! SKIPPING: UNKNOWN NODE TYPE"
        return False

def TBSDKEXPreconstructConstrainData():
    TBSDKEXPsetResultText("")
    TBSDKEXPdelete()
    TBSDKEXPsetResultText("")
    constructedCounter = 0
    totalCounter = 0
    global TBSDKEXPnI, TBSDKEXPdnI, TBSDKEXPexportDataObject, TBSDKEXPwl
    TBSDKEXPdnI = 0
    TBSDKEXPnI = 1
    tbsdkexpLastSplitNI = 0
    exportDataObjectI = 1
    TBSDKEXPexportObjectCreate(exportDataObjectI)
    TBSDKEXPexportDataObject = TBSDKEXPexportObject(exportDataObjectI)
    TBSDKEXPwl = mc.checkBox(TBSDKEXPworkLogCheckbox, q=True, v=True)
    sceneObjects = []
    selection = mc.ls(sl=True)
    if len(selection) == 0:
        sceneObjects = mc.ls(l=True, tr=True)
    else:
    	sceneObjects = mc.ls(l=True, tr=True, sl=True)
    for sceneObject in sceneObjects:
        firstDriver = mc.setDrivenKeyframe(sceneObject, q=True, dr=True)[0]
        if firstDriver != "No drivers.":
            if TBSDKEXPwl: print "|\n|\n<<<<< " + sceneObject
            drivenChannels = mc.setDrivenKeyframe(sceneObject, q=True, dn=True)
            for drivenChannel in drivenChannels:
                drivenChannelFullpath = mc.ls(drivenChannel, l=True)[0]
                result = TBSDKEXPconstructConstrainDataDrivenChannel(drivenChannelFullpath, False, sceneObject)
                totalCounter += 1
                if result:
                    if TBSDKEXPwl: print "      <<< CONSTRUCT >>>"
                    if TBSDKEXPnI > (tbsdkexpLastSplitNI + 200):
                    	exportDataObjectI += 1
                    	TBSDKEXPexportObjectCreate(exportDataObjectI)
                    	TBSDKEXPexportDataObject = TBSDKEXPexportObject(exportDataObjectI)
                    	tbsdkexpLastSplitNI = TBSDKEXPnI
                    TBSDKEXPdnI += 1
                    dnIstr = str(TBSDKEXPdnI)
                    mc.addAttr(TBSDKEXPexportDataObject, ln="dc_"+dnIstr, nn="dc_"+dnIstr, dt="string")
                    mc.setAttr(TBSDKEXPexportDataObject + ".dc_"+dnIstr, drivenChannelFullpath, type="string")
                    mc.addAttr(TBSDKEXPexportDataObject, ln="dcn_"+dnIstr, nn="dcn_"+dnIstr, at="long", dv=TBSDKEXPnI)
                    TBSDKEXPconstructConstrainDataDrivenChannel(drivenChannel, True, sceneObject)
                    constructedCounter += 1
                    TBSDKEXPsetResultText(str(constructedCounter) + "/" + str(totalCounter) + " driven channels data constructed")
                    mc.refresh()
                else:
                    if TBSDKEXPwl: print "      <<< !! SKIP CONSTRUCT !! >>>"
    if constructedCounter == 0: TBSDKEXPdelete(True)
    del(TBSDKEXPnI, TBSDKEXPdnI, TBSDKEXPexportDataObject)

def TBSDKEXPexportObjectCreate(num):
    mc.createNode("transform", n="TBSDKexportData_"+str(num), ss=True)
def TBSDKEXPexportObject(num):
    exportObjects = mc.ls("|TBSDKexportData_"+str(num), l=True)
    if exportObjects: return exportObjects[0]
    else: return ""
def TBSDKEXPsets():
    mel.eval('SetDrivenKeyOptions;')
def TBSDKEXPdelete(silent=False):
    if not silent: TBSDKEXPsetResultText("")
    done = False
    num = 0
    deletedNum = 0
    while not done:
    	num += 1
    	exportObject = TBSDKEXPexportObject(num)
    	if exportObject:
    		mc.delete(exportObject)
    		deletedNum += 1
    	else:
    		done = True
    if not silent:
    	if deletedNum > 0: TBSDKEXPsetResultText("deleted " + str(deletedNum) + " data objects")
    	else: TBSDKEXPsetResultText("nothing to delete")
def TBSDKEXPconstruct():
    TBSDKEXPreconstructConstrainData()
def TBSDKEXPselectAll():
    mc.select(all=True)
def TBSDKEXPsendAsNew():
    mel.eval('SendAsNewSceneMotionBuilder;')
def TBSDKEXPsendUpdate():
    mel.eval('UpdateCurrentSceneMotionBuilder;')
# Window
windowID = "TBsdkExport"
if mc.window(windowID, exists=True): mc.deleteUI(windowID)
mc.window(windowID, t="TB SDK Export", mxb=False)
parentLayout = mc.columnLayout(adj=True, rs=1)

row1 = mc.rowLayout(p=parentLayout, nc=3, h=40)
mc.columnLayout(p=row1, w=80)
mc.button(l="SDK", w=80, h=40, c="TBSDKEXPsets()")
mc.columnLayout(p=row1, w=80)
mc.button(l="Construct", w=80, h=23, c="TBSDKEXPconstruct()")
TBSDKEXPworkLogCheckbox = mc.checkBox(l="Work Log", w=80, h=17, v=False)
mc.columnLayout(p=row1, w=80)
mc.button(l="Delete", w=80, h=40, c="TBSDKEXPdelete()")
row2 = mc.rowLayout(p=parentLayout, nc=3, h=40)
mc.columnLayout(p=row2, w=80)
mc.button(l="Select All", w=80, h=40, c="TBSDKEXPselectAll()")
mc.columnLayout(p=row2, w=80)
mc.button(l="Send as New", w=80, h=40, c="TBSDKEXPsendAsNew()")
mc.columnLayout(p=row2, w=80)
mc.button(l="Send Update", w=80, h=40, c="TBSDKEXPsendUpdate()")
mc.rowLayout(p=parentLayout, nc=1)
TBSDKEXPresultText = mc.text(l="", w=244, h=13, al="right")
mc.text(TBSDKEXPresultText, e=True, l="")
mc.showWindow()
del(parentLayout,windowID)